﻿using System;

namespace Curd_Operation080622.Models
{
    public class TeacherJoin
    {
        public int Teacher_Id { get; set; }
        public string Teacher_Name { get; set; }
        public int Teacher_Age { get; set; }
        public string Teacher_Address { get; set; }
        public int Teacher_Salary { get; set; }
        public string Teahching_Class { get; set; }
        public DateTime DOJ { get; set; }
        public int Country { get; set; }
        public int Gender { get; set; }
        public string Hobbie { get; set; }

        public string CName { get; set; }
        public string Gender_Name { get; set; }

        public string Hobby_Name { get; set; }
    

}
}
